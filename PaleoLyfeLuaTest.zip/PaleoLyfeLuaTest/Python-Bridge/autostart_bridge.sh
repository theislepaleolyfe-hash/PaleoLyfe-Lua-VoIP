#!/bin/bash

BRIDGE_DIR="/home/container/paleo_bridge"
POSITION_FILE="/home/container/TheIsle/Content/UE4SS/Mods/PaleoVoIP/paleovoip_position.json"

cd "$BRIDGE_DIR"

echo "[PaleoVoIP] Auto-restart bridge is now running."

while true
do
    echo "[PaleoVoIP] Starting bridge..."
    python3 bridge.py \
        --position-file "$POSITION_FILE" \
        --rate 20 \
        --context PaleoVoIP \
        --quiet

    echo "[PaleoVoIP] Bridge crashed or exited. Restarting in 3 seconds..."
    sleep 3
done
