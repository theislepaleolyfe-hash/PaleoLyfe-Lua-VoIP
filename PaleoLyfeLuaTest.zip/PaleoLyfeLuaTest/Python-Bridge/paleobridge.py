import argparse
import ctypes
import json
import mmap
import os
import platform
import struct
import sys
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any


LINK_SIZE = 4096
NAME_CHARS = 256
IDENTITY_CHARS = 256
DESCRIPTION_CHARS = 2048
CONTEXT_SIZE = 256


def _wide(text: str, max_chars: int) -> bytes:
    encoded = text.encode("utf-16-le", errors="replace")
    if len(encoded) > max_chars * 2:
        encoded = encoded[: max_chars * 2]
    return encoded.ljust(max_chars * 2, b"\x00")


def _vec3(value: Any, fallback: tuple[float, float, float]) -> tuple[float, float, float]:
    if not isinstance(value, (list, tuple)) or len(value) != 3:
        return fallback
    try:
        return float(value[0]), float(value[1]), float(value[2])
    except Exception:
        return fallback


def _normalize(v: tuple[float, float, float], fallback: tuple[float, float, float]) -> tuple[float, float, float]:
    length = (v[0] * v[0] + v[1] * v[1] + v[2] * v[2]) ** 0.5
    if length <= 1e-6:
        return fallback
    return (v[0] / length, v[1] / length, v[2] / length)


@dataclass(frozen=True)
class Snapshot:
    steam_id64: str
    context: str
    position: tuple[float, float, float]
    front: tuple[float, float, float]
    top: tuple[float, float, float]


class MumbleLink:
    def __init__(self) -> None:
        self._mapping = self._open_mapping()
        self._tick = 0

    def close(self) -> None:
        self._mapping.close()

    def write(self, snapshot: Snapshot) -> None:
        self._tick = (self._tick + 1) & 0xFFFFFFFF
        identity = json.dumps(
            {"steam_id64": snapshot.steam_id64},
            separators=(",", ":"),
        )
        context_bytes = snapshot.context.encode("utf-8", errors="replace")[:CONTEXT_SIZE]
        description = "PaleoVoIP UE4SS positional audio bridge"

        parts = [
            struct.pack("<II", 2, self._tick),
            struct.pack("<3f", *snapshot.position),
            struct.pack("<3f", *snapshot.front),
            struct.pack("<3f", *snapshot.top),
            _wide("PaleoVoIP", NAME_CHARS),
            struct.pack("<3f", *snapshot.position),
            struct.pack("<3f", *snapshot.front),
            struct.pack("<3f", *snapshot.top),
            _wide(identity, IDENTITY_CHARS),
            struct.pack("<I", len(context_bytes)),
            context_bytes.ljust(CONTEXT_SIZE, b"\x00"),
            _wide(description, DESCRIPTION_CHARS),
        ]
        payload = b"".join(parts)
        if len(payload) != LINK_SIZE:
            raise RuntimeError(f"Internal Mumble Link size mismatch: {len(payload)} != {LINK_SIZE}")

        self._mapping.seek(0)
        self._mapping.write(payload)
        self._mapping.flush()

    @staticmethod
    def _open_mapping() -> mmap.mmap:
        if platform.system().lower().startswith("win"):
            return mmap.mmap(-1, LINK_SIZE, tagname="MumbleLink")
        return _open_posix_mumble_link()


def _open_posix_mumble_link() -> mmap.mmap:
    libc = ctypes.CDLL(None, use_errno=True)
    shm_open = libc.shm_open
    shm_open.argtypes = [ctypes.c_char_p, ctypes.c_int, ctypes.c_int]
    shm_open.restype = ctypes.c_int
    ftruncate = libc.ftruncate
    ftruncate.argtypes = [ctypes.c_int, ctypes.c_long]
    ftruncate.restype = ctypes.c_int

    name = f"/MumbleLink.{os.getuid()}".encode("ascii")
    flags = os.O_RDWR | os.O_CREAT
    fd = shm_open(name, flags, 0o600)
    if fd < 0:
        errno = ctypes.get_errno()
        raise OSError(errno, os.strerror(errno), name.decode())

    try:
        if ftruncate(fd, LINK_SIZE) != 0:
            errno = ctypes.get_errno()
            raise OSError(errno, os.strerror(errno), name.decode())
        return mmap.mmap(fd, LINK_SIZE, mmap.MAP_SHARED, mmap.PROT_WRITE | mmap.PROT_READ)
    finally:
        os.close(fd)


def read_snapshot(path: Path, steam_id64_override: str | None, context_override: str | None) -> Snapshot:
    raw = path.read_text(encoding="utf-8")
    data = json.loads(raw)

    steam_id64 = steam_id64_override or str(data.get("steam_id64") or "")
    context = context_override or str(data.get("context") or "PaleoVoIP")
    position = _vec3(data.get("position_m"), (0.0, 0.0, 0.0))
    front = _normalize(_vec3(data.get("front"), (0.0, 0.0, 1.0)), (0.0, 0.0, 1.0))
    top = _normalize(_vec3(data.get("top"), (0.0, 1.0, 0.0)), (0.0, 1.0, 0.0))

    return Snapshot(
        steam_id64=steam_id64,
        context=context,
        position=position,
        front=front,
        top=top,
    )


def _load_config(path: Path | None) -> dict[str, Any]:
    if path is None:
        return {}
    with path.open("r", encoding="utf-8") as handle:
        loaded = json.load(handle)
    if not isinstance(loaded, dict):
        raise ValueError("Bridge config must be a JSON object.")
    return loaded


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Bridge UE4SS position snapshots to Mumble Link.")
    parser.add_argument("--config", type=Path, help="Optional JSON config file.")
    parser.add_argument("--position-file", type=Path, help="Path to paleovoip_position.json.")
    parser.add_argument("--steam-id64", default=None, help="Override SteamID64 if the game does not expose it.")
    parser.add_argument("--context", default=None, help="Override Mumble context. Players must share the same context.")
    parser.add_argument("--rate", type=float, help="Polling rate in Hz. Default: 20.")
    parser.add_argument("--stale-timeout", type=float, help="Seconds before warning about stale data. Default: 2.")
    parser.add_argument("--quiet", action="store_true", help="Suppress status logging.")
    args = parser.parse_args()
    config = _load_config(args.config)

    if args.position_file is None and config.get("position_file"):
        args.position_file = Path(str(config["position_file"]))
    if args.position_file is None:
        parser.error("--position-file is required unless provided by --config")

    if args.steam_id64 is None and config.get("steam_id64"):
        args.steam_id64 = str(config["steam_id64"])
    if args.context is None and config.get("context"):
        args.context = str(config["context"])
    if args.rate is None:
        args.rate = float(config.get("rate", 20.0))
    if args.stale_timeout is None:
        args.stale_timeout = float(config.get("stale_timeout", 2.0))

    return args


def main() -> int:
    args = parse_args()
    interval = 1.0 / max(args.rate, 1.0)
    link = MumbleLink()
    last_mtime = 0.0
    last_log = 0.0

    if not args.quiet:
        print(f"PaleoVoIP bridge writing Mumble Link on {platform.system()}.")
        print(f"Reading {args.position_file}")

    try:
        while True:
            try:
                stat = args.position_file.stat()
                snapshot = read_snapshot(args.position_file, args.steam_id64, args.context)
                link.write(snapshot)

                now = time.monotonic()
                if not args.quiet and now - last_log > 5.0:
                    fresh = "fresh" if stat.st_mtime != last_mtime else "unchanged"
                    print(
                        f"{fresh}: steam_id64={snapshot.steam_id64 or 'unknown'} "
                        f"pos=({snapshot.position[0]:.2f}, {snapshot.position[1]:.2f}, {snapshot.position[2]:.2f})"
                    )
                    last_log = now
                last_mtime = stat.st_mtime
            except FileNotFoundError:
                if not args.quiet and time.monotonic() - last_log > args.stale_timeout:
                    print(f"Waiting for {args.position_file} ...")
                    last_log = time.monotonic()
            except (json.JSONDecodeError, OSError, RuntimeError) as exc:
                if not args.quiet and time.monotonic() - last_log > 1.0:
                    print(f"Bridge warning: {exc}", file=sys.stderr)
                    last_log = time.monotonic()

            time.sleep(interval)
    except KeyboardInterrupt:
        return 0
    finally:
        link.close()


if __name__ == "__main__":
    raise SystemExit(main())
