#!/bin/bash

echo "=============================================="
echo "   PaleoVoIP Auto-Healing System"
echo "=============================================="
echo ""

UE4SS_MOD="/home/container/TheIsle/Content/UE4SS/Mods/PaleoVoIP"
POSITION_FILE="$UE4SS_MOD/paleovoip_position.json"
BRIDGE_DIR="/home/container/paleo_bridge"
BRIDGE_PROCESS="bridge.py"
START_SCRIPT="$BRIDGE_DIR/start_bridge.sh"
SHM_NAME="/dev/shm/MumbleLink.$UID"

heal_count=0

heal() {
    echo "   → Healing: $1"
    heal_count=$((heal_count+1))
}

# 1. Ensure UE4SS mod folder exists
echo "[1] Checking UE4SS mod folder..."
if [ ! -d "$UE4SS_MOD" ]; then
    echo "   ✖ Missing UE4SS mod folder"
    heal "Recreating PaleoVoIP mod folder"
    mkdir -p "$UE4SS_MOD/Scripts"
    mkdir -p "$UE4SS_MOD/Config"
fi
echo "   ✔ UE4SS mod folder OK"

# 2. Ensure paleovoip.lua exists
echo "[2] Checking paleovoip.lua..."
if [ ! -f "$UE4SS_MOD/Scripts/paleovoip.lua" ]; then
    echo "   ✖ paleovoip.lua missing"
    heal "Restoring paleovoip.lua placeholder"
    echo "-- Lua script missing. Please re-upload." > "$UE4SS_MOD/Scripts/paleovoip.lua"
fi
echo "   ✔ paleovoip.lua OK"

# 3. Ensure JSON output exists
echo "[3] Checking JSON output..."
if [ ! -f "$POSITION_FILE" ]; then
    echo "   ✖ JSON missing"
    heal "Creating empty JSON file"
    echo '{"position_m":[0,0,0],"front":[1,0,0],"top":[0,0,1],"steam_id64":"","context":"PaleoVoIP"}' > "$POSITION_FILE"
fi
echo "   ✔ JSON file exists"

# 4. Check JSON freshness
MOD_TIME=$(stat -c %Y "$POSITION_FILE")
NOW=$(date +%s)
AGE=$((NOW - MOD_TIME))

if [ $AGE -gt 5 ]; then
    echo "   ✖ JSON stale ($AGE seconds old)"
    heal "Forcing UE4SS refresh by touching file"
    touch "$POSITION_FILE"
else
    echo "   ✔ JSON fresh"
fi

# 5. Ensure Python bridge is running
echo "[4] Checking Python bridge..."
if ! pgrep -f "$BRIDGE_PROCESS" > /dev/null; then
    echo "   ✖ bridge.py not running"
    heal "Restarting bridge"
    bash "$START_SCRIPT" &
    sleep 2
else
    echo "   ✔ bridge.py running"
fi

# 6. Ensure MumbleLink shared memory exists
echo "[5] Checking MumbleLink shared memory..."
if [ ! -f "$SHM_NAME" ]; then
    echo "   ✖ MumbleLink shared memory missing"
    heal "Triggering bridge to recreate shared memory"
    pkill -f "$BRIDGE_PROCESS"
    bash "$START_SCRIPT" &
    sleep 2
else
    echo "   ✔ MumbleLink shared memory OK"
fi

echo ""
echo "=============================================="
echo "   Auto-Healing Complete"
echo "=============================================="
echo "   Total fixes applied: $heal_count"
echo "=============================================="
