@echo off
set UEPAK="C:\Program Files\Epic Games\UE_4.27\Engine\Binaries\Win64\UnrealPak.exe"
set OUTPAK="C:\mods\PaleoVoIP.pak"
set PAKLIST="C:\mods\PakList.txt"

%UEPAK% %OUTPAK% -Create=%PAKLIST% -Compress

echo Built %OUTPAK%
pause
