local json = require("json")

local output_path = "paleovoip_position.json"

RegisterHook("/Script/Engine.PlayerController:Tick", function(Context)
    local Player = Context:get()
    if Player == nil then return end

    local Pawn = Player.Pawn
    if Pawn == nil then return end

    local pos = Pawn:K2_GetActorLocation()
    local rot = Pawn:K2_GetActorRotation()

    local front = {
        math.cos(math.rad(rot.Yaw)),
        math.sin(math.rad(rot.Yaw)),
        0
    }

    local top = { 0, 0, 1 }

    local data = {
        position_m = { pos.X, pos.Y, pos.Z },
        front = front,
        top = top,
        steam_id64 = "",
        context = "PaleoVoIP"
    }

    local file = io.open(output_path, "w")
    if file then
        file:write(json.encode(data))
        file:close()
    end
end)
